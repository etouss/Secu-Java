package securiteL3;
import java.util.HashSet;

public class MyHash extends HashSet<Character> {
}

